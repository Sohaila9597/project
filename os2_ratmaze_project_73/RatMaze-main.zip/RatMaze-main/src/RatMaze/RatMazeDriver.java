
package RatMaze;

public class RatMazeDriver {

    public static void main(String[] args) {
        new MainFrame();
    }
    
}
